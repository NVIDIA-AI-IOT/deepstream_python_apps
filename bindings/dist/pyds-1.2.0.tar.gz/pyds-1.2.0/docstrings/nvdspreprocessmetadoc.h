/*
 * SPDX-FileCopyrightText: Copyright (c) 2021-2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

namespace pydsdoc 
{
    namespace nvdspreprocessmetadoc 
    {
        namespace NvDsPreProcessTensorMetaDoc {
            constexpr const char* descr = R"pyds(Metadata structure for preprocessed tensors.)pyds";
            constexpr const char* cast = R"pyds(Casts a pointer to NvDsPreProcessTensorMeta)pyds";
        }

        // Descriptions for GstNvDsPreProcessBatchMeta fields
        namespace GstNvDsPreProcessBatchMetaDoc {
            constexpr const char* descr = R"pyds(Batch metadata structure for preprocessing operations)pyds";
            constexpr const char* cast = R"pyds(Casts a pointer to GstNvDsPreProcessBatchMeta)pyds";
        }
    }  
}  

